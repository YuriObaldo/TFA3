<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\Files\UploadedFile;
use CodeIgniter\HTTP\RedirectResponse;

class Users extends BaseController
{
    /** Display-ready avatars are public; raw uploads are held privately (writable/) only while processing. */
    private const AVATAR_DIR  = FCPATH . 'uploads/avatars/';
    private const AVATAR_SIZE = 200; // px, square thumbnail

    private UserModel $users;

    public function __construct()
    {
        $this->users = new UserModel();
    }

    public function index(): string
    {
        try {
            $users = $this->users->orderBy('username', 'ASC')->findAll();
        } catch (\Throwable $e) {
            log_message('error', 'Unable to load users: ' . $e->getMessage());
            $users = [];
        }

        return view('users', [
            'title' => 'User Accounts',
            'users' => $users,
        ]);
    }

    /** GET /users/new */
    public function new(): string
    {
        return view('user_form', [
            'title'  => 'New User',
            'user'   => null,
            'action' => site_url('users'),
        ]);
    }

    /** POST /users */
    public function create(): RedirectResponse
    {
        if (! $this->validate($this->rules())) {
            return redirect()->to(site_url('users/new'))
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $this->users->insert($this->formData());

        return redirect()->to(site_url('users'))
            ->with('success', 'User added successfully.');
    }

    /** GET /users/{id}/edit */
    public function edit(int $id): string
    {
        return view('user_form', [
            'title'  => 'Edit User',
            'user'   => $this->findOr404($id),
            'action' => site_url('users/' . $id),
        ]);
    }

    /** POST /users/{id} - validate, handle the optional avatar, then update. */
    public function update(int $id): RedirectResponse
    {
        $user    = $this->findOr404($id);
        $file    = $this->request->getFile('avatar');
        $hasFile = $file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE;
        $back    = site_url("users/{$id}/edit");

        if (! $this->validate($this->rules($id, $hasFile))) {
            return redirect()->to($back)
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $data = $this->formData();

        if ($hasFile) {
            try {
                $data['avatar'] = $this->storeAvatar($file);
            } catch (\Throwable $e) {
                log_message('error', 'Avatar upload failed: ' . $e->getMessage());

                return redirect()->to($back)
                    ->withInput()
                    ->with('errors', ['avatar' => 'The image could not be processed. Please try a different JPG or PNG.']);
            }
        }

        $this->users->update($id, $data);

        // Remove the previous avatar only after the new record is saved.
        if ($hasFile && ! empty($user['avatar'])) {
            $this->deleteAvatar($user['avatar']);
        }

        return redirect()->to(site_url('users'))
            ->with('success', 'User updated successfully.');
    }

    private function findOr404(int $id): array
    {
        $user = $this->users->find($id);

        if ($user === null) {
            throw PageNotFoundException::forPageNotFound("User #{$id} was not found.");
        }

        return $user;
    }

    private function rules(?int $id = null, bool $withAvatar = false): array
    {
        // On edit, ignore the current row so a user can keep their own username.
        $unique = $id === null ? 'is_unique[users.username]' : "is_unique[users.username,id,{$id}]";

        $rules = [
            'username' => [
                'label'  => 'Username',
                'rules'  => "required|min_length[3]|max_length[50]|regex_match[/^[A-Za-z0-9._-]+$/]|{$unique}",
                'errors' => [
                    'required'    => 'Username is required.',
                    'is_unique'   => 'That username is already taken.',
                    'regex_match' => 'Username may only contain letters, numbers, dots, dashes and underscores.',
                ],
            ],
            'full_name' => [
                'label'  => 'Full name',
                'rules'  => 'required|min_length[2]|max_length[100]',
                'errors' => ['required' => 'Full name is required.'],
            ],
            'role' => [
                'label' => 'Role',
                'rules' => 'permit_empty|max_length[50]',
            ],
        ];

        if ($withAvatar) {
            $rules['avatar'] = [
                'label'  => 'Profile picture',
                'rules'  => 'uploaded[avatar]'
                    . '|is_image[avatar]'
                    . '|mime_in[avatar,image/jpg,image/jpeg,image/png]'
                    . '|ext_in[avatar,jpg,jpeg,png]'
                    . '|max_size[avatar,2048]', // KB => 2 MB
                'errors' => [
                    'uploaded'  => 'The upload failed. Please choose the file again.',
                    'is_image'  => 'The file must be a real image.',
                    'mime_in'   => 'The profile picture must be a JPG or PNG.',
                    'ext_in'    => 'The profile picture must be a .jpg, .jpeg or .png file.',
                    'max_size'  => 'The profile picture must not be larger than 2 MB.',
                ],
            ];
        }

        return $rules;
    }

    private function formData(): array
    {
        return [
            'username'  => trim((string) $this->request->getPost('username')),
            'full_name' => trim((string) $this->request->getPost('full_name')),
            'role'      => trim((string) $this->request->getPost('role')),
        ];
    }

    /**
     * Move the raw upload to private storage under a random name, build a
     * square thumbnail in the public folder, discard the raw file, and
     * return the filename (the only thing stored in the database).
     */
    private function storeAvatar(UploadedFile $file): string
    {
        if (! is_dir(self::AVATAR_DIR)) {
            mkdir(self::AVATAR_DIR, 0755, true);
        }

        $tmpDir  = WRITEPATH . 'uploads/';
        $newName = $file->getRandomName();
        $file->move($tmpDir, $newName);

        $source = $tmpDir . $newName;

        try {
            service('image')
                ->withFile($source)
                ->fit(self::AVATAR_SIZE, self::AVATAR_SIZE, 'center')
                ->save(self::AVATAR_DIR . $newName, 85);
        } finally {
            @unlink($source); // never keep the raw upload around
        }

        return $newName;
    }

    private function deleteAvatar(string $filename): void
    {
        $path = self::AVATAR_DIR . basename($filename); // basename() blocks path tricks

        if (is_file($path)) {
            @unlink($path);
        }
    }
}
