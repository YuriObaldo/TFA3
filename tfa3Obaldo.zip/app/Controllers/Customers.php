<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\RedirectResponse;

class Customers extends BaseController
{
    private CustomerModel $customers;

    public function __construct()
    {
        $this->customers = new CustomerModel();
    }

    public function index(): string
    {
        try {
            $customers = $this->customers->orderBy('full_name', 'ASC')->findAll();
        } catch (\Throwable $e) {
            log_message('error', 'Unable to load customers: ' . $e->getMessage());
            $customers = [];
        }

        return view('customers', [
            'title'     => 'Customer Accounts',
            'customers' => $customers,
        ]);
    }

    /** GET /customers/new - show the empty form. */
    public function new(): string
    {
        return view('customer_form', [
            'title'    => 'New Customer',
            'customer' => null,
            'action'   => site_url('customers'),
        ]);
    }

    /** POST /customers - validate, then insert. */
    public function create(): RedirectResponse
    {
        if (! $this->validate($this->rules())) {
            return redirect()->to(site_url('customers/new'))
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $this->customers->insert($this->formData());

        return redirect()->to(site_url('customers'))
            ->with('success', 'Customer added successfully.');
    }

    /** GET /customers/{id}/edit - form pre-filled with the existing record. */
    public function edit(int $id): string
    {
        return view('customer_form', [
            'title'    => 'Edit Customer',
            'customer' => $this->findOr404($id),
            'action'   => site_url('customers/' . $id),
        ]);
    }

    /** POST /customers/{id} - validate, then update. */
    public function update(int $id): RedirectResponse
    {
        $this->findOr404($id);

        if (! $this->validate($this->rules())) {
            return redirect()->to(site_url("customers/{$id}/edit"))
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $this->customers->update($id, $this->formData());

        return redirect()->to(site_url('customers'))
            ->with('success', 'Customer updated successfully.');
    }

    private function findOr404(int $id): array
    {
        $customer = $this->customers->find($id);

        if ($customer === null) {
            throw PageNotFoundException::forPageNotFound("Customer #{$id} was not found.");
        }

        return $customer;
    }

    private function rules(): array
    {
        return [
            'full_name' => [
                'label'  => 'Full name',
                'rules'  => 'required|min_length[2]|max_length[100]',
                'errors' => ['required' => 'Full name is required.'],
            ],
            'email' => [
                'label'  => 'Email',
                'rules'  => 'required|valid_email|max_length[100]',
                'errors' => [
                    'required'    => 'Email is required.',
                    'valid_email' => 'Please enter a valid email address.',
                ],
            ],
            'phone' => [
                'label' => 'Phone',
                'rules' => 'permit_empty|max_length[20]',
            ],
        ];
    }

    /** Only the whitelisted, trimmed fields from the form. */
    private function formData(): array
    {
        return [
            'full_name' => trim((string) $this->request->getPost('full_name')),
            'email'     => trim((string) $this->request->getPost('email')),
            'phone'     => trim((string) $this->request->getPost('phone')),
        ];
    }
}
