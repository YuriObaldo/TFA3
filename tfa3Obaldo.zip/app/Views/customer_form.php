<?php
$errors = session('errors') ?? [];
$isEdit = $customer !== null;
?>
<?= $this->include('layouts/header') ?>
<section class="card">
    <h2><?= esc($title) ?></h2>

    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">Please fix the errors below and try again.</div>
    <?php endif ?>

    <form action="<?= esc($action, 'attr') ?>" method="post" novalidate>
        <?= csrf_field() ?>

        <div class="field">
            <label for="full_name">Full name *</label>
            <input type="text" id="full_name" name="full_name"
                   class="<?= isset($errors['full_name']) ? 'invalid' : '' ?>"
                   value="<?= old('full_name', $isEdit ? $customer['full_name'] : '') ?>">
            <?php if (isset($errors['full_name'])): ?><p class="field-error"><?= esc($errors['full_name']) ?></p><?php endif ?>
        </div>

        <div class="field">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email"
                   class="<?= isset($errors['email']) ? 'invalid' : '' ?>"
                   value="<?= old('email', $isEdit ? $customer['email'] : '') ?>">
            <?php if (isset($errors['email'])): ?><p class="field-error"><?= esc($errors['email']) ?></p><?php endif ?>
        </div>

        <div class="field">
            <label for="phone">Phone</label>
            <input type="text" id="phone" name="phone"
                   class="<?= isset($errors['phone']) ? 'invalid' : '' ?>"
                   value="<?= old('phone', $isEdit ? $customer['phone'] : '') ?>">
            <?php if (isset($errors['phone'])): ?><p class="field-error"><?= esc($errors['phone']) ?></p><?php endif ?>
        </div>

        <div class="actions">
            <button class="button" type="submit"><?= $isEdit ? 'Save changes' : 'Add customer' ?></button>
            <a class="button button-secondary" href="<?= site_url('customers') ?>">Cancel</a>
        </div>
    </form>
</section>
<?= $this->include('layouts/footer') ?>
