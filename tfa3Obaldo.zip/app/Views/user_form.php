<?php
$errors = session('errors') ?? [];
$isEdit = $user !== null;
$avatarUrl = $isEdit && ! empty($user['avatar'])
    ? base_url('uploads/avatars/' . $user['avatar'])
    : base_url('assets/img/avatar-placeholder.svg');
?>
<?= $this->include('layouts/header') ?>
<section class="card">
    <h2><?= esc($title) ?></h2>

    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">Please fix the errors below and try again.</div>
    <?php endif ?>

    <form action="<?= esc($action, 'attr') ?>" method="post" enctype="multipart/form-data" novalidate>
        <?= csrf_field() ?>

        <div class="field">
            <label for="username">Username *</label>
            <input type="text" id="username" name="username"
                   class="<?= isset($errors['username']) ? 'invalid' : '' ?>"
                   value="<?= old('username', $isEdit ? $user['username'] : '') ?>">
            <?php if (isset($errors['username'])): ?><p class="field-error"><?= esc($errors['username']) ?></p><?php endif ?>
        </div>

        <div class="field">
            <label for="full_name">Full name *</label>
            <input type="text" id="full_name" name="full_name"
                   class="<?= isset($errors['full_name']) ? 'invalid' : '' ?>"
                   value="<?= old('full_name', $isEdit ? $user['full_name'] : '') ?>">
            <?php if (isset($errors['full_name'])): ?><p class="field-error"><?= esc($errors['full_name']) ?></p><?php endif ?>
        </div>

        <div class="field">
            <label for="role">Role</label>
            <input type="text" id="role" name="role"
                   class="<?= isset($errors['role']) ? 'invalid' : '' ?>"
                   value="<?= old('role', $isEdit ? $user['role'] : '') ?>">
            <?php if (isset($errors['role'])): ?><p class="field-error"><?= esc($errors['role']) ?></p><?php endif ?>
        </div>

        <?php if ($isEdit): ?>
            <div class="field">
                <label for="avatar">Profile picture</label>
                <p><img class="avatar avatar-large" src="<?= esc($avatarUrl, 'attr') ?>" alt="Current avatar"></p>
                <input type="file" id="avatar" name="avatar" accept="image/jpeg,image/png"
                       class="<?= isset($errors['avatar']) ? 'invalid' : '' ?>">
                <p class="hint">JPG or PNG, up to 2 MB. Leave empty to keep the current picture.</p>
                <?php if (isset($errors['avatar'])): ?><p class="field-error"><?= esc($errors['avatar']) ?></p><?php endif ?>
            </div>
        <?php else: ?>
            <p class="hint">You can upload a profile picture after the account is created, from its Edit page.</p>
        <?php endif ?>

        <div class="actions">
            <button class="button" type="submit"><?= $isEdit ? 'Save changes' : 'Add user' ?></button>
            <a class="button button-secondary" href="<?= site_url('users') ?>">Cancel</a>
        </div>
    </form>
</section>
<?= $this->include('layouts/footer') ?>
