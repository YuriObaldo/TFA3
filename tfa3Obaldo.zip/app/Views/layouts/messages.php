<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success" role="status"><?= esc(session()->getFlashdata('success')) ?></div>
<?php endif ?>
