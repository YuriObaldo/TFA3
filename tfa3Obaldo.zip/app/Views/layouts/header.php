<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?> | POS</title>
    <style>
        :root { font-family: Arial, sans-serif; }
        body { background: #f4f6f8; color: #1f2937; margin: 0; }
        header { background: #17324d; color: #fff; padding: 1rem 2rem; }
        header h1 { margin: 0 0 .75rem; font-size: 1.35rem; }
        nav { display: flex; flex-wrap: wrap; gap: 1rem; }
        nav a { color: #fff; text-decoration: none; }
        nav a:hover, nav a:focus { text-decoration: underline; }
        main { margin: 2rem auto; max-width: 960px; padding: 0 1rem; }
        .card { background: #fff; border-radius: .5rem; box-shadow: 0 2px 8px #00000012; padding: 2rem; }
        .actions { display: flex; flex-wrap: wrap; gap: .75rem; margin-top: 1.5rem; }
        .button { background: #2563eb; border-radius: .35rem; color: #fff; display: inline-block; padding: .7rem 1rem; text-decoration: none; }
        table { border-collapse: collapse; margin-top: 1.5rem; width: 100%; }
        th, td { border-bottom: 1px solid #e5e7eb; padding: .85rem .75rem; text-align: left; }
        th { background: #eef2ff; }
        .card-head { align-items: center; display: flex; flex-wrap: wrap; gap: 1rem; justify-content: space-between; }
        .button-secondary { background: #6b7280; }
        .button-small { font-size: .85rem; padding: .4rem .7rem; }
        .alert { border-radius: .35rem; margin-bottom: 1rem; padding: .75rem 1rem; }
        .alert-success { background: #dcfce7; color: #166534; }
        .alert-error { background: #fee2e2; color: #991b1b; }
        .field { margin-bottom: 1.1rem; }
        .field label { display: block; font-weight: bold; margin-bottom: .35rem; }
        .field input[type=text], .field input[type=email], .field input[type=file] { border: 1px solid #cbd5e1; border-radius: .35rem; box-sizing: border-box; padding: .6rem; width: 100%; }
        .field input.invalid { border-color: #dc2626; }
        .field-error { color: #b91c1c; font-size: .9rem; margin: .3rem 0 0; }
        .hint { color: #6b7280; font-size: .85rem; margin: .3rem 0 0; }
        .avatar { background: #e5e7eb; border-radius: 50%; height: 48px; object-fit: cover; width: 48px; }
        .avatar-large { height: 96px; width: 96px; }
        footer { color: #6b7280; font-size: .9rem; margin: 2rem auto; max-width: 960px; padding: 0 1rem; }
    </style>
</head>
<body>
<header>
    <h1>Point of Sale</h1>
    <nav aria-label="Main navigation">
        <a href="<?= site_url('/') ?>">Home</a>
        <a href="<?= site_url('about') ?>">About</a>
        <a href="<?= site_url('customers') ?>">Customer Accounts</a>
        <a href="<?= site_url('users') ?>">User Accounts</a>
    </nav>
</header>
<main>
<?= $this->include('layouts/messages') ?>
