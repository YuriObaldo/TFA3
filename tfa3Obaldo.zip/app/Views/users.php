<?= $this->include('layouts/header') ?>
<section class="card">
    <div class="card-head">
        <h2>User Accounts</h2>
        <a class="button" href="<?= site_url('users/new') ?>">+ New User</a>
    </div>
    <p>Staff records are loaded from the application database.</p>
    <table>
        <thead>
            <tr>
                <th>Avatar</th>
                <th>Username</th>
                <th>Full name</th>
                <th>Created at</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <?php
                $avatarUrl = ! empty($user['avatar'])
                    ? base_url('uploads/avatars/' . $user['avatar'])
                    : base_url('assets/img/avatar-placeholder.svg');
                ?>
                <tr>
                    <td>
                        <img class="avatar" src="<?= esc($avatarUrl, 'attr') ?>"
                             alt="Avatar of <?= esc($user['username'], 'attr') ?>"
                             onerror="this.onerror=null;this.src='<?= base_url('assets/img/avatar-placeholder.svg') ?>'">
                    </td>
                    <td><?= esc($user['username']) ?></td>
                    <td><?= esc($user['full_name']) ?></td>
                    <td><?= esc($user['created_at']) ?></td>
                    <td><a class="button button-small" href="<?= site_url('users/' . $user['id'] . '/edit') ?>">Edit</a></td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</section>
<?= $this->include('layouts/footer') ?>
