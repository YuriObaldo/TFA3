<?= $this->include('layouts/header') ?>
<section class="card">
    <div class="card-head">
        <h2>Customer Accounts</h2>
        <a class="button" href="<?= site_url('customers/new') ?>">+ New Customer</a>
    </div>
    <p>Customer records are loaded from the application database.</p>
    <table>
        <thead>
            <tr>
                <th>Full name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($customers as $customer): ?>
                <tr>
                    <td><?= esc($customer['full_name']) ?></td>
                    <td><?= esc($customer['email']) ?></td>
                    <td><?= esc($customer['phone']) ?></td>
                    <td><a class="button button-small" href="<?= site_url('customers/' . $customer['id'] . '/edit') ?>">Edit</a></td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</section>
<?= $this->include('layouts/footer') ?>
